"""
AI diff analyzer — turns a git diff into a structured review using Ollama.

This is the piece referenced in the spec's "AI Diff Analyzer" section.
Responsibilities:
    - accept changed files + diff text (collected by pm.git, see
      modules/git/diff.py — this file never touches git itself)
    - build a size-bounded prompt (prompts.py does fine-grained
      truncation; MAX_DIFF_CHARS here is the outer safety net so we
      never even hand prompts.py an enormous diff)
    - send to Ollama via the shared OllamaClient
    - parse the structured response back into named sections

Note: your uploaded `analyzer.py` was an accidental duplicate of
`prompts.py` — this file is the actual analyzer logic that was missing.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from ..exceptions import OllamaError
from .ollama import OllamaClient
from .prompts import (
    SYSTEM_ANALYST,
    SYSTEM_COMMIT_MSG,
    build_commit_message_prompt,
    build_diff_analysis_prompt,
)

log = logging.getLogger("pm.ai.analyzer")

# Outer safety net before a diff ever reaches prompts.py's own truncation.
MAX_FILES = 200
MAX_DIFF_CHARS = 20_000


@dataclass
class AnalysisResult:
    text: str
    summary: str = ""
    changes: str = ""
    risks: str = ""
    suggestions: str = ""
    commit_message: str = ""


class DiffAnalyzer:
    """
    Builds prompts from git diff data and asks a local Ollama model
    for a structured review plus a suggested commit message.

    Usage:
        analyzer = DiffAnalyzer(host=cfg.host, model=cfg.model, timeout=cfg.timeout)
        files, diff_text = pm.git.collect_diff()
        result = analyzer.analyze("my-project", files, diff_text)
        print(result.text)
    """

    def __init__(self, host: str, model: str, timeout: int = 120) -> None:
        self._client = OllamaClient(host=host, model=model, timeout=timeout)

    def analyze(
        self,
        project_name: str,
        changed_files: list[str],
        diff: str,
        extra_context: str = "",
    ) -> AnalysisResult:
        files = changed_files[:MAX_FILES]
        bounded_diff = self._bound(diff)

        prompt = build_diff_analysis_prompt(
            project_name=project_name,
            changed_files=files,
            diff=bounded_diff,
            extra_context=extra_context,
        )
        try:
            response = self._client.generate(prompt, system=SYSTEM_ANALYST)
        except OllamaError:
            log.exception("AI analysis failed")
            raise
        return self._parse(response.text)

    def commit_message(self, project_name: str, changed_files: list[str], diff: str) -> str:
        """Ask the model for just a conventional-commit message (no full review)."""
        prompt = build_commit_message_prompt(
            project_name=project_name,
            changed_files=changed_files[:MAX_FILES],
            diff=self._bound(diff),
        )
        response = self._client.generate(prompt, system=SYSTEM_COMMIT_MSG)
        text = response.text.strip().strip("`")
        return text.splitlines()[0].strip() if text else ""

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _bound(self, diff: str) -> str:
        """Chunk/truncate oversized diffs (keep head + tail) before prompts.py."""
        if len(diff) <= MAX_DIFF_CHARS:
            return diff
        half = MAX_DIFF_CHARS // 2
        head, tail = diff[:half], diff[-half:]
        skipped = len(diff) - len(head) - len(tail)
        return f"{head}\n\n... [{skipped} chars omitted] ...\n\n{tail}"

    def _parse(self, text: str) -> AnalysisResult:
        sections = {
            "summary": r"Project Summary\s*-*\s*\n(.*?)(?=\n\s*Changes:|\Z)",
            "changes": r"Changes:\s*\n(.*?)(?=\n\s*Risks:|\Z)",
            "risks": r"Risks:\s*\n(.*?)(?=\n\s*Suggestions:|\Z)",
            "suggestions": r"Suggestions:\s*\n(.*?)(?=\n\s*Commit Message:|\Z)",
            "commit_message": r"Commit Message:\s*\n(.*)",
        }
        parsed: dict[str, str] = {}
        for key, pattern in sections.items():
            m = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            parsed[key] = m.group(1).strip() if m else ""
        return AnalysisResult(text=text, **parsed)
