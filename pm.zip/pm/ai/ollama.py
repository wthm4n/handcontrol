"""
Reusable Ollama client for local LLM inference.

Supported models (tested):
    qwen2.5-coder:7b-instruct-q4_K_M  (default — best for code)
    qwen2.5:7b-instruct
    llama3.2:3b

Never uses cloud APIs. Never requires OpenAI.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Iterator

from ..exceptions import OllamaError

log = logging.getLogger("pm.ollama")

SUPPORTED_MODELS = [
    "qwen2.5-coder:7b-instruct-q4_K_M",
    "qwen2.5:7b-instruct",
    "llama3.2:3b",
]
DEFAULT_MODEL = "qwen2.5-coder:7b-instruct-q4_K_M"


@dataclass
class OllamaResponse:
    text: str
    model: str
    done: bool
    prompt_tokens: int = 0
    completion_tokens: int = 0


class OllamaClient:
    """
    Thin HTTP client for the Ollama /api/generate endpoint.

    Usage:
        client = OllamaClient(host="http://localhost:11434", model="qwen2.5-coder:7b-instruct-q4_K_M")
        response = client.generate("Summarise this diff:\n...")
        print(response.text)
    """

    def __init__(
        self,
        host: str = "http://localhost:11434",
        model: str = DEFAULT_MODEL,
        timeout: int = 120,
    ) -> None:
        self.host = host.rstrip("/")
        self.model = model
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(self, prompt: str, system: str | None = None) -> OllamaResponse:
        """Send a prompt to Ollama and return the complete response."""
        payload = self._build_payload(prompt, system, stream=False)
        raw = self._post("/api/generate", payload)
        return self._parse_response(raw)

    def stream(self, prompt: str, system: str | None = None) -> Iterator[str]:
        """Stream tokens from Ollama as they arrive."""
        payload = self._build_payload(prompt, system, stream=True)
        url = f"{self.host}/api/generate"
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                for line in resp:
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line.decode())
                        token = chunk.get("response", "")
                        if token:
                            yield token
                        if chunk.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue
        except urllib.error.URLError as exc:
            raise OllamaError(f"Ollama stream failed ({url}): {exc}") from exc

    def is_available(self) -> bool:
        """Check that Ollama is running and the model is available."""
        try:
            raw = self._get("/api/tags")
            models = [m.get("name", "") for m in raw.get("models", [])]
            return any(self.model in m for m in models)
        except OllamaError:
            return False

    def list_models(self) -> list[str]:
        """Return names of all locally available models."""
        try:
            raw = self._get("/api/tags")
            return [m.get("name", "") for m in raw.get("models", [])]
        except OllamaError:
            return []

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_payload(self, prompt: str, system: str | None, stream: bool) -> dict:
        payload: dict = {
            "model": self.model,
            "prompt": prompt,
            "stream": stream,
        }
        if system:
            payload["system"] = system
        return payload

    def _post(self, path: str, payload: dict) -> dict:
        url = f"{self.host}{path}"
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.URLError as exc:
            raise OllamaError(f"Ollama request failed ({url}): {exc}") from exc
        except json.JSONDecodeError as exc:
            raise OllamaError(f"Ollama returned invalid JSON: {exc}") from exc

    def _get(self, path: str) -> dict:
        url = f"{self.host}{path}"
        req = urllib.request.Request(url, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.URLError as exc:
            raise OllamaError(f"Ollama GET failed ({url}): {exc}") from exc

    def _parse_response(self, raw: dict) -> OllamaResponse:
        return OllamaResponse(
            text=raw.get("response", ""),
            model=raw.get("model", self.model),
            done=raw.get("done", True),
            prompt_tokens=raw.get("prompt_eval_count", 0),
            completion_tokens=raw.get("eval_count", 0),
        )

    def __repr__(self) -> str:
        return f"<OllamaClient host={self.host!r} model={self.model!r}>"
