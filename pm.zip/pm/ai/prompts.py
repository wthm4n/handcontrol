"""Prompt templates for PM AI features."""

from __future__ import annotations

SYSTEM_ANALYST = """\
You are a senior software engineer reviewing code changes for a project.
Your job is to provide concise, actionable analysis.
Respond only with the requested structured format — no preamble, no markdown fences.
"""

SYSTEM_COMMIT_MSG = """\
You are a senior software engineer writing git commit messages.
Follow the Conventional Commits specification.
Return ONLY the commit message — nothing else.
Examples:
  feat(formatter): add Python comment stripper
  fix(git): handle detached HEAD state
  refactor(eventbus): simplify subscriber model
  chore(config): rename source_controller to git
"""


def build_diff_analysis_prompt(
    project_name: str,
    changed_files: list[str],
    diff: str,
    extra_context: str = "",
) -> str:
    files_block = "\n".join(f"  - {f}" for f in changed_files[:50])
    diff_block = _truncate(diff, max_chars=6000)
    ctx_block = _truncate(extra_context, max_chars=1000) if extra_context else ""

    parts = [
        f"Project: {project_name}",
        "",
        "Changed files:",
        files_block,
        "",
        "Diff:",
        diff_block,
    ]
    if ctx_block:
        parts += ["", "Additional context:", ctx_block]

    parts += [
        "",
        "Respond in exactly this format:",
        "",
        "Project Summary",
        "---------------",
        "<one sentence summary>",
        "",
        "Changes:",
        "<bullet list of key changes>",
        "",
        "Risks:",
        "<bullet list of risks or 'None identified'>",
        "",
        "Suggestions:",
        "<bullet list of suggestions or 'None'>",
        "",
        "Commit Message:",
        "<conventional commit message>",
    ]
    return "\n".join(parts)


def build_commit_message_prompt(
    project_name: str,
    changed_files: list[str],
    diff: str,
) -> str:
    files_block = "\n".join(f"  - {f}" for f in changed_files[:30])
    diff_block = _truncate(diff, max_chars=4000)
    return (
        f"Project: {project_name}\n\n"
        f"Changed files:\n{files_block}\n\n"
        f"Diff:\n{diff_block}\n\n"
        "Write a conventional commit message for these changes."
    )


def _truncate(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    keep = max_chars - 100
    return text[:keep] + f"\n\n... [truncated {len(text) - keep} chars]"
