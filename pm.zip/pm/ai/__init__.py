"""AI integration — local Ollama client, prompt templates, diff analyzer."""
