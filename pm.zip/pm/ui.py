"""All Rich rendering lives here. Commands call these functions instead of
building panels/tables inline — keeps the visual style consistent and
commands.py focused on logic.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from . import git

BRAND = "cyan"


def make_console() -> Console:
    return Console()


def header(ctx) -> Panel:
    cfg = ctx.config
    branch = git.current_branch(cfg.root) if git.is_repo(cfg.root) else "no-repo"
    title = Text("PM v3", style=f"bold {BRAND}")
    right = Text(f"{cfg.project.name}/{branch}", style="dim")
    line = Text.assemble(title, "  ", right)
    return Panel(line, border_style=BRAND, padding=(0, 1))


def status_panel(ctx) -> Panel:
    cfg = ctx.config
    rows = [
        ("Git", git.is_repo(cfg.root)),
        ("Ollama", cfg.ollama.enabled and ctx.ai.is_available()),
        ("Sync", bool(ctx.sync and ctx.sync.is_running)),
    ]
    text = Text()
    for i, (label, ok) in enumerate(rows):
        icon, style = ("✓", "green") if ok else ("✗", "red")
        text.append(f"{icon} ", style=style)
        text.append(f"{label} {'Connected' if label != 'Sync' else 'Running' if ok else 'Stopped'}")
        if i < len(rows) - 1:
            text.append("\n")
    return Panel(text, title="Project Status", border_style="grey50", padding=(0, 1))


def activity_panel(ctx, n: int = 8) -> Panel:
    events = ctx.activity.recent(n)
    if not events:
        body: Text | str = Text("No activity yet.", style="dim")
    else:
        body = Text()
        for i, e in enumerate(events):
            body.append(f"{e.time_str} ", style="dim")
            body.append(f"{e.icon} ", style=e.color)
            body.append(e.message)
            if i < len(events) - 1:
                body.append("\n")
    return Panel(body, title="Activity", border_style="grey50", padding=(0, 1))


def render_dashboard(ctx) -> None:
    ctx.console.print(header(ctx))
    ctx.console.print(status_panel(ctx))
    ctx.console.print(activity_panel(ctx))


def print_event(ctx, message: str, level: str = "info") -> None:
    """Record + immediately print one activity line — used by the
    background sync thread so changes show up without a full redraw."""
    event = ctx.activity.add(message, level)
    ctx.console.print(f"[dim]{event.time_str}[/dim] [{event.color}]{event.icon}[/{event.color}] {message}")


def info(ctx, message: str) -> None:
    ctx.console.print(f"[cyan]●[/cyan] {message}")


def success(ctx, message: str) -> None:
    ctx.console.print(f"[green]✓[/green] {message}")


def warn(ctx, message: str) -> None:
    ctx.console.print(f"[yellow]![/yellow] {message}")


def error(ctx, message: str) -> None:
    ctx.console.print(f"[red]✗[/red] {message}")


def table(title: str, columns: list[str]) -> Table:
    t = Table(title=title, border_style="grey50", title_style=f"bold {BRAND}")
    for col in columns:
        t.add_column(col)
    return t


def render_help_index(ctx, commands: dict) -> None:
    t = table("Commands", ["Command", "Description"])
    for name in sorted(commands):
        t.add_row(f"/{name}", commands[name].description)
    ctx.console.print(t)
    ctx.console.print("[dim]Run /help <command> for usage and examples.[/dim]")


def render_help_command(ctx, spec) -> None:
    body = Text()
    body.append("Description:\n", style="bold")
    body.append(f"{spec.description}\n\n")
    if spec.usage:
        body.append("Usage:\n", style="bold")
        body.append("\n".join(spec.usage) + "\n\n")
    if spec.examples:
        body.append("Examples:\n", style="bold")
        body.append("\n".join(spec.examples))
    ctx.console.print(Panel(body, title=f"/{spec.name}", border_style=BRAND))


def render_doctor(ctx, checks: list[tuple[str, bool, str]]) -> None:
    t = table("Doctor", ["Check", "Status", "Detail"])
    for label, ok, detail in checks:
        icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
        t.add_row(label, icon, detail)
    ctx.console.print(t)


def render_models(ctx, models: list[str], current: str, installed: list[str]) -> None:
    t = table("Models", ["Model", "Current", "Installed"])
    for m in models:
        t.add_row(m, "✓" if m == current else "", "✓" if m in installed else "")
    ctx.console.print(t)


def render_files(ctx, files: list[str]) -> None:
    t = table(f"Files ({len(files)})", ["Path"])
    for f in files[:200]:
        t.add_row(f)
    ctx.console.print(t)
    if len(files) > 200:
        ctx.console.print(f"[dim]... and {len(files) - 200} more[/dim]")


def render_git_changes(ctx, changes) -> None:
    if not changes:
        ctx.console.print("[dim]Nothing changed.[/dim]")
        return
    t = table("Changed Files", ["Status", "Path"])
    for c in changes:
        t.add_row(c.status, c.path)
    ctx.console.print(t)
