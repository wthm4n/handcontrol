"""
Event bus — the central nervous system of PM.

Modules never call each other directly. They emit events and subscribe to events.
PM's event bus is the only communication channel between modules.

Usage:
    bus = EventBus()

    # Subscribe
    bus.subscribe("file_changed", my_callback)

    # Emit (synchronous delivery to all subscribers)
    bus.emit("file_changed", path="/src/main.py")

    # Unsubscribe
    bus.unsubscribe("file_changed", my_callback)
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable

log = logging.getLogger("pm.eventbus")

Callback = Callable[..., None]

# Well-known event names — add new events here as the system grows.
# Modules may also emit ad-hoc string events; these constants are for discovery.
class Events:
    # Watcher
    FILE_CHANGED   = "file_changed"
    FILE_CREATED   = "file_created"
    FILE_DELETED   = "file_deleted"

    # Formatter
    FORMATTER_STARTED   = "formatter_started"
    FORMATTER_COMPLETED = "formatter_completed"
    FILE_FORMATTED      = "file_formatted"

    # Git
    GIT_STAGED     = "git_staged"
    GIT_COMMITTED  = "git_committed"
    GIT_PUSHED     = "git_pushed"
    GIT_PULLED     = "git_pulled"

    # AI
    AI_ANALYSIS_STARTED   = "ai_analysis_started"
    AI_ANALYSIS_COMPLETED = "ai_analysis_completed"

    # Tasks
    TASK_STARTED   = "task_started"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED    = "task_failed"

    # PM lifecycle
    PM_LOADED      = "pm_loaded"
    PM_SHUTDOWN    = "pm_shutdown"


class EventBus:
    """
    Synchronous, in-process publish/subscribe event bus.

    All handlers are called in subscription order. Exceptions in handlers
    are logged and swallowed so one bad handler cannot break the chain.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[Callback]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def subscribe(self, event: str, callback: Callback) -> None:
        """Register *callback* to be called whenever *event* is emitted."""
        if callback not in self._subscribers[event]:
            self._subscribers[event].append(callback)
            log.debug("subscribed %s → %s", event, _cb_name(callback))

    def unsubscribe(self, event: str, callback: Callback) -> None:
        """Remove *callback* from *event* subscriptions (no-op if not found)."""
        try:
            self._subscribers[event].remove(callback)
            log.debug("unsubscribed %s → %s", event, _cb_name(callback))
        except ValueError:
            pass

    def emit(self, event: str, **payload: Any) -> None:
        """
        Deliver *event* to all subscribers.

        Keyword arguments become the event payload and are passed through
        to every handler as keyword arguments.
        """
        handlers = list(self._subscribers.get(event, []))
        log.debug("emit %s → %d handler(s) | %s", event, len(handlers), payload)
        for handler in handlers:
            try:
                handler(**payload)
            except Exception:
                log.exception(
                    "Handler %s raised on event %r", _cb_name(handler), event
                )

    def subscribers(self, event: str) -> list[Callback]:
        """Return a copy of the subscriber list for *event*."""
        return list(self._subscribers.get(event, []))

    def clear(self, event: str | None = None) -> None:
        """Remove all subscribers for *event*, or all events if None."""
        if event is None:
            self._subscribers.clear()
        else:
            self._subscribers.pop(event, None)

    def __repr__(self) -> str:
        total = sum(len(v) for v in self._subscribers.values())
        return f"<EventBus events={list(self._subscribers)} total_handlers={total}>"


def _cb_name(cb: Callback) -> str:
    return getattr(cb, "__qualname__", repr(cb))
