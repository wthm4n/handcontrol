"""Built-in PM tasks: format, analyze, sync. Pure orchestration over pm.* APIs."""
