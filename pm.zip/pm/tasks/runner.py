"""Task runner — registry + dispatcher for named tasks (format, analyze, sync, ...).

This is the module manager.py already imports (`from .tasks.runner import
TaskRunner`) but that never existed yet.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Callable

from ..eventbus import Events
from ..exceptions import TaskError, TaskNotFoundError
from ..module import Module
from . import analyze as analyze_task
from . import format as format_task
from . import sync as sync_task

if TYPE_CHECKING:
    from ..manager import ProjectManager

log = logging.getLogger("pm.tasks")

TaskFunc = Callable[["ProjectManager"], dict]


class TaskRunner(Module):
    """
    Registry + dispatcher for named tasks.

    Built-in tasks:
        format   -> pm.formatter.run()
        analyze  -> AI diff analysis (pm/ai/analyzer.py via pm.git.collect_diff())
        sync     -> format -> analyze -> commit -> push

    Usage:
        pm.tasks.run("sync")
        pm.tasks.run()  # uses [tasks].default from config
    """

    name = "tasks"

    def setup(self, pm: "ProjectManager") -> None:
        self._pm = pm
        self._tasks: dict[str, TaskFunc] = {}
        self.register("format", format_task.run)
        self.register("analyze", analyze_task.run)
        self.register("sync", sync_task.run)

    def register(self, name: str, func: TaskFunc) -> None:
        """Register a new task — this is the extension point for custom tasks."""
        self._tasks[name] = func

    def list_tasks(self) -> list[str]:
        return list(self._tasks)

    def run(self, name: str | None = None) -> dict:
        name = name or self._pm.config.tasks.default
        if name not in self._tasks:
            raise TaskNotFoundError(
                f"No such task: {name!r} (available: {self.list_tasks()})"
            )
        log.info("[tasks] Running: %s", name)
        self._pm.events.emit(Events.TASK_STARTED, task=name)
        try:
            result = self._tasks[name](self._pm)
        except Exception as exc:
            log.exception("[tasks] %s failed", name)
            self._pm.events.emit(Events.TASK_FAILED, task=name, error=str(exc))
            raise TaskError(f"Task '{name}' failed: {exc}") from exc
        self._pm.events.emit(Events.TASK_COMPLETED, task=name, result=result)
        log.info("[tasks] %s completed", name)
        return result
