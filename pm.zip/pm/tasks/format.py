"""Task: format — run the formatter module over the whole project."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..manager import ProjectManager


def run(pm: "ProjectManager") -> dict:
    return pm.formatter.run()
