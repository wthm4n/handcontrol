"""Task: analyze — AI-powered diff analysis via Ollama.

This is the only place that wires pm.git (raw diff data) together with
pm.ai.analyzer (AI logic). Neither module talks to the other directly.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..ai.analyzer import DiffAnalyzer
from ..eventbus import Events

if TYPE_CHECKING:
    from ..manager import ProjectManager

log = logging.getLogger("pm.tasks.analyze")


def run(pm: "ProjectManager") -> dict:
    cfg = pm.config.ollama
    if not cfg.enabled:
        log.info("[ollama] Disabled in config — skipping AI analysis")
        return {"enabled": False, "analysis": None, "commit_message": ""}

    log.info("[ollama] Generating analysis")
    pm.events.emit(Events.AI_ANALYSIS_STARTED)

    analyzer = DiffAnalyzer(host=cfg.host, model=cfg.model, timeout=cfg.timeout)
    changed_files, diff_text = pm.git.collect_diff()

    if not diff_text.strip():
        result = {"enabled": True, "analysis": "(no changes to analyze)", "commit_message": ""}
        pm.events.emit(Events.AI_ANALYSIS_COMPLETED, analysis=result["analysis"])
        return result

    analysis = analyzer.analyze(
        project_name=pm.config.project.name,
        changed_files=changed_files,
        diff=diff_text,
    )
    pm.events.emit(Events.AI_ANALYSIS_COMPLETED, analysis=analysis.text)
    return {
        "enabled": True,
        "analysis": analysis.text,
        "commit_message": analysis.commit_message,
    }
