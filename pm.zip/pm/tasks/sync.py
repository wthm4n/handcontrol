"""Task: sync — format -> analyze -> commit -> push.

This is the only place an AI-generated commit message reaches git.commit():
it's passed in as a plain string here, never resolved inside the git module.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from . import analyze as analyze_task

if TYPE_CHECKING:
    from ..manager import ProjectManager

log = logging.getLogger("pm.tasks.sync")


def run(pm: "ProjectManager") -> dict:
    result: dict = {}

    result["format"] = pm.formatter.run()
    result["analyze"] = analyze_task.run(pm)

    commit_message = None
    if pm.config.git.auto_commit_message:
        commit_message = result["analyze"].get("commit_message") or None

    result["commit"] = pm.git.commit(commit_message)
    result["push"] = pm.git.push() if result["commit"] else None

    log.info("[sync] Completed successfully")
    return result
