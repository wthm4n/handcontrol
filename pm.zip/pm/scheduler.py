"""
Scheduler — event-driven task runner with future cron/interval support.

Current philosophy: events come first. The scheduler reacts to events
emitted on the event bus rather than polling a timer. Timer/cron support
is architectured for future use but not activated.

Future config hooks (not yet implemented):
    [scheduler]
    interval = 60
    cron = "*/5 * * * *"
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from .manager import ProjectManager

log = logging.getLogger("pm.scheduler")

Job = Callable[[], None]


class Scheduler:
    """
    Lightweight scheduler that maps event names to callable jobs.

    When an event arrives on the bus the corresponding job is executed
    in a worker thread so it does not block the event bus.

    Architecture note: interval/cron scheduling is intentionally left as
    stub — extend _start_interval() and _start_cron() when needed.
    """

    def __init__(self) -> None:
        self._jobs: dict[str, list[Job]] = {}
        self._lock = threading.Lock()
        self._pm: ProjectManager | None = None

    def setup(self, pm: "ProjectManager") -> None:
        self._pm = pm

    # ------------------------------------------------------------------
    # Event-driven scheduling
    # ------------------------------------------------------------------

    def on_event(self, event: str, job: Job) -> None:
        """Run *job* every time *event* fires."""
        with self._lock:
            self._jobs.setdefault(event, []).append(job)
        if self._pm is not None:
            self._pm.events.subscribe(event, self._make_handler(job))
        log.debug("Scheduled %s on event %r", _job_name(job), event)

    def _make_handler(self, job: Job) -> Callable:
        def handler(**_payload):
            t = threading.Thread(target=self._run_job, args=(job,), daemon=True)
            t.start()
        return handler

    def _run_job(self, job: Job) -> None:
        try:
            job()
        except Exception:
            log.exception("Scheduled job %s raised", _job_name(job))

    # ------------------------------------------------------------------
    # Future: interval / cron (stub)
    # ------------------------------------------------------------------

    def every(self, seconds: int, job: Job) -> None:  # pragma: no cover
        """[Future] Run *job* every *seconds* seconds."""
        log.warning("Interval scheduling not yet implemented (job=%s)", _job_name(job))

    def cron(self, expression: str, job: Job) -> None:  # pragma: no cover
        """[Future] Run *job* on a cron schedule."""
        log.warning("Cron scheduling not yet implemented (expr=%s job=%s)", expression, _job_name(job))

    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"<Scheduler jobs={list(self._jobs)}>"


def _job_name(job: Job) -> str:
    return getattr(job, "__qualname__", repr(job))
