"""Shared data shapes used across PM.

Everything here is a plain dataclass — no behavior, no I/O. Keeping the
shapes in one place means config.py, ui.py, commands.py, sync.py etc. can
all import the same definitions instead of redefining little structs.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional


@dataclass
class ProjectConfig:
    name: str = "project"


@dataclass
class OllamaConfig:
    enabled: bool = True
    model: str = "qwen2.5-coder:7b-instruct-q4_K_M"
    host: str = "http://localhost:11434"
    timeout: int = 60


@dataclass
class SyncConfig:
    enabled: bool = False
    debounce_seconds: float = 30
    push: bool = True


@dataclass
class GitConfig:
    branch: str = "main"
    remote: str = "origin"
    fallback_commit_message: str = "chore: update {file}"


@dataclass
class FormatterConfig:
    enabled: bool = True
    max_blank_lines: int = 2


@dataclass
class Config:
    version: int = 3
    project: ProjectConfig = field(default_factory=ProjectConfig)
    ollama: OllamaConfig = field(default_factory=OllamaConfig)
    sync: SyncConfig = field(default_factory=SyncConfig)
    git: GitConfig = field(default_factory=GitConfig)
    formatter: FormatterConfig = field(default_factory=FormatterConfig)
    ignore: list[str] = field(default_factory=list)


    root: Path = field(default_factory=Path.cwd)
    path: Optional[Path] = None


@dataclass
class ActivityEvent:
    message: str
    level: str = "info"
    at: float = field(default_factory=time.time)

    @property
    def time_str(self) -> str:
        return time.strftime("%H:%M", time.localtime(self.at))

    @property
    def icon(self) -> str:
        return {
            "info": "●",
            "success": "✓",
            "warn": "!",
            "error": "✗",
        }.get(self.level, "●")

    @property
    def color(self) -> str:
        return {
            "info": "cyan",
            "success": "green",
            "warn": "yellow",
            "error": "red",
        }.get(self.level, "white")


@dataclass
class AppContext:
    """The one object passed to every command handler. Holds config, the
    Ollama client, the activity feed, the Rich console, and (once started)
    the sync controller. Avoids every command needing a long parameter list."""

    config: Config
    ai: Any
    activity: Any
    console: Any
    sync: Any = None
    running: bool = True


@dataclass
class CommandSpec:
    name: str
    handler: Callable[["object", list[str]], None]
    description: str
    usage: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)
