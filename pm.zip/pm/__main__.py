"""Entry point: `python3 -m pm`

Finds the project root, loads .src, builds the shared AppContext, shows
the dashboard once, then drops into a slash-command REPL.
"""

from __future__ import annotations

from pathlib import Path

from . import ai, commands, config, ui
from .models import AppContext
from .sync import SyncController
from .utils import ActivityFeed


def build_context() -> AppContext:
    root = config.find_root() or Path.cwd()
    cfg = config.load_config(root)

    client = ai.OllamaClient(host=cfg.ollama.host, model=cfg.ollama.model, timeout=cfg.ollama.timeout)
    ctx = AppContext(config=cfg, ai=client, activity=ActivityFeed(), console=ui.make_console())
    ctx.sync = SyncController(ctx)
    return ctx


def main() -> None:
    ctx = build_context()

    if ctx.config.path is None:
        ui.warn(ctx, "No .src config found — using defaults. Run /config init to create one.")

    if ctx.config.sync.enabled:
        ctx.sync.start()

    ui.render_dashboard(ctx)

    while ctx.running:
        try:
            raw = ctx.console.input("[bold cyan]>[/bold cyan] ")
        except (EOFError, KeyboardInterrupt):
            ctx.console.print()
            commands.cmd_exit(ctx, [])
            break
        commands.dispatch(ctx, raw)


if __name__ == "__main__":
    main()
