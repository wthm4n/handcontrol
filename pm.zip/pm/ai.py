"""Local Ollama integration. One client, one set of prompts, one commit
message implementation — every code path that needs an AI commit message
calls `generate_commit_message()` below. Nothing else re-implements it.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass

from .utils import truncate

SUPPORTED_MODELS = [
    "qwen2.5-coder:7b-instruct-q4_K_M",
    "qwen2.5:7b-instruct",
    "llama3.2:3b",
]

SYSTEM_COMMIT_MSG = """\
You are a senior software engineer writing a git commit message for a \
single file change. Follow the Conventional Commits spec. Return ONLY the \
commit message, one line, nothing else — no quotes, no markdown.
"""

SYSTEM_REVIEW = """\
You are a senior software engineer reviewing a code change. Be concise \
and concrete. Respond only with the requested structure, no preamble.
"""


class OllamaError(Exception):
    pass


@dataclass
class OllamaClient:
    host: str = "http://localhost:11434"
    model: str = SUPPORTED_MODELS[0]
    timeout: int = 60

    def generate(self, prompt: str, system: str | None = None) -> str:
        payload: dict = {"model": self.model, "prompt": prompt, "stream": False}
        if system:
            payload["system"] = system
        raw = self._post("/api/generate", payload)
        return raw.get("response", "").strip()

    def is_available(self) -> bool:
        try:
            self._get("/api/tags")
            return True
        except OllamaError:
            return False

    def list_models(self) -> list[str]:
        try:
            raw = self._get("/api/tags")
            return [m.get("name", "") for m in raw.get("models", [])]
        except OllamaError:
            return []

    def _post(self, path: str, payload: dict) -> dict:
        req = urllib.request.Request(
            f"{self.host}{path}",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except (urllib.error.URLError, TimeoutError) as exc:
            raise OllamaError(str(exc)) from exc
        except json.JSONDecodeError as exc:
            raise OllamaError(f"invalid JSON from Ollama: {exc}") from exc

    def _get(self, path: str) -> dict:
        req = urllib.request.Request(f"{self.host}{path}", method="GET")
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                return json.loads(resp.read().decode())
        except (urllib.error.URLError, TimeoutError) as exc:
            raise OllamaError(str(exc)) from exc


# ---------------------------------------------------------------------------
# High-level helpers — these are what the rest of PM calls.
# ---------------------------------------------------------------------------

def generate_commit_message(
    client: OllamaClient,
    enabled: bool,
    fallback: str,
    file: str,
    diff: str,
) -> tuple[str, str]:
    """Returns (message, source) where source is "ollama" or "fallback".
    This is the single implementation of "ask AI, fall back on failure"."""
    fallback_msg = fallback.format(file=file)
    if not enabled or not diff.strip():
        return fallback_msg, "fallback"

    prompt = (
        f"File: {file}\n\nDiff:\n{truncate(diff, 4000)}\n\n"
        "Write a one-line conventional commit message for this change."
    )
    try:
        message = client.generate(prompt, system=SYSTEM_COMMIT_MSG)
    except OllamaError:
        return fallback_msg, "fallback"

    message = message.strip().strip('"').splitlines()[0] if message else ""
    if not message:
        return fallback_msg, "fallback"
    return message, "ollama"


def analyze_diff(client: OllamaClient, project: str, files: list[str], diff: str) -> str:
    files_block = "\n".join(f"  - {f}" for f in files[:50])
    prompt = (
        f"Project: {project}\n\nChanged files:\n{files_block}\n\n"
        f"Diff:\n{truncate(diff, 6000)}\n\n"
        "Respond in this format:\n\n"
        "Summary:\n<one sentence>\n\nChanges:\n<bullet list>\n\n"
        "Risks:\n<bullet list or 'None identified'>"
    )
    try:
        return client.generate(prompt, system=SYSTEM_REVIEW)
    except OllamaError as exc:
        raise OllamaError(f"Analysis failed: {exc}") from exc


def review_diff(client: OllamaClient, file: str, diff: str) -> str:
    prompt = (
        f"File: {file}\n\nDiff:\n{truncate(diff, 6000)}\n\n"
        "Review this change. Respond in this format:\n\n"
        "Quality:\n<one sentence>\n\nIssues:\n<bullet list or 'None'>\n\n"
        "Suggestions:\n<bullet list or 'None'>"
    )
    try:
        return client.generate(prompt, system=SYSTEM_REVIEW)
    except OllamaError as exc:
        raise OllamaError(f"Review failed: {exc}") from exc
