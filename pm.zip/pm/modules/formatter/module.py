"""Formatter module — strips comments, emits events."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from ...eventbus import Events
from ...module import Module
from .format import run_formatter

if TYPE_CHECKING:
    from ...manager import ProjectManager

log = logging.getLogger("pm.formatter")

_CACHE_FILENAME = ".fmt_cache.json"


class FormatterModule(Module):
    """
    Runs the comment-stripping formatter over the project.

    Subscribes to Events.FILE_CHANGED when auto_format is enabled,
    so files are automatically formatted after each save.

    Emits:
        Events.FORMATTER_STARTED
        Events.FILE_FORMATTED  (path=str)
        Events.FORMATTER_COMPLETED (processed=int, unchanged=int, errors=int)
    """

    name = "formatter"

    def setup(self, pm: "ProjectManager") -> None:
        self._pm = pm
        self._cfg = pm.config.formatter
        self._root = pm.root
        self._cache_path = pm.root / _CACHE_FILENAME
        self._ignore_pm = pm.config.project.ignore_pm

        if self._cfg.auto_format:
            pm.events.subscribe(Events.FILE_CHANGED, self._on_file_changed)
            log.debug("Auto-format enabled — subscribed to FILE_CHANGED")

    def run(self) -> dict:
        """Run formatter over entire project tree."""
        log.info("Running formatter on %s", self._root)
        self._pm.events.emit(Events.FORMATTER_STARTED)
        result = run_formatter(
            root=self._root,
            cache_path=self._cache_path,
            max_blank_lines=self._cfg.max_blank_lines,
            ignore_pm=self._ignore_pm,
        )
        for f in result.get("files", []):
            self._pm.events.emit(Events.FILE_FORMATTED, path=f)
        self._pm.events.emit(
            Events.FORMATTER_COMPLETED,
            processed=result["processed"],
            unchanged=result["unchanged"],
            errors=result["errors"],
        )
        log.info(
            "Formatter done: processed=%d unchanged=%d errors=%d",
            result["processed"], result["unchanged"], result["errors"],
        )
        return result

    def _on_file_changed(self, path: Path, event_type: str = "modified", **_) -> None:
        """Trigger a full format run when any file changes."""
        log.debug("[watcher] → formatter triggered by %s", path)
        self.run()
