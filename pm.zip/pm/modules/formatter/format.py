"""
Core formatting engine.

Architecture:
    - Discovers files under a root directory
    - Applies the appropriate remover/formatter per extension
    - Uses a SHA-256 hash cache to skip unchanged files
    - Performs atomic writes (write tmp → rename)
    - Validates Python AST after transformation

To add a new language formatter:
    1. Create a class with .extensions list and .process(source: str) -> str
    2. Register it in FORMATTERS below
"""

from __future__ import annotations

import ast
import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Optional, Protocol

from .comments import PythonCommentRemover

log = logging.getLogger("pm.formatter")

MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB

IGNORED_DIRS = frozenset({
    ".git", "__pycache__", ".venv", "venv", "build", "dist",
    ".mypy_cache", ".pytest_cache", ".tox", "node_modules", ".idea",
})

BINARY_EXTENSIONS = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp",
    ".onnx", ".pt", ".pth", ".pkl", ".pickle",
    ".dll", ".so", ".exe", ".bin", ".dylib", ".pyc", ".pyd", ".whl",
    ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z", ".rar",
    ".db", ".sqlite", ".sqlite3", ".pdf",
    ".mp3", ".mp4", ".wav", ".ogg", ".flac", ".avi", ".mov",
})

ENCODING_FALLBACKS = ["utf-8", "utf-8-sig", "latin1"]


class Formatter(Protocol):
    extensions: list[str]
    def process(self, source: str) -> str: ...


def _build_formatters(max_blank_lines: int) -> dict[str, Formatter]:
    remover = PythonCommentRemover(max_blank_lines=max_blank_lines)
    return {ext: remover for ext in remover.extensions}


# ------------------------------------------------------------------
# Cache
# ------------------------------------------------------------------

def _load_cache(cache_path: Path) -> dict[str, str]:
    if not cache_path.is_file():
        return {}
    try:
        with cache_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def _save_cache(cache: dict[str, str], cache_path: Path) -> None:
    tmp = cache_path.with_suffix(".tmp")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(cache, f, indent=2, sort_keys=True)
        os.replace(tmp, cache_path)
    except OSError as exc:
        log.warning("Could not save formatter cache: %s", exc)


def _file_hash(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            sha.update(chunk)
    return sha.hexdigest()


# ------------------------------------------------------------------
# Discovery
# ------------------------------------------------------------------

def _is_binary(path: Path) -> bool:
    if path.suffix.lower() in BINARY_EXTENSIONS:
        return True
    try:
        with path.open("rb") as f:
            return b"\x00" in f.read(8192)
    except OSError:
        return True


def _discover(
    root: Path,
    formatters: dict[str, Formatter],
    ignore_pm: bool = True,
) -> list[Path]:
    found: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dp = Path(dirpath)
        dirnames[:] = [
            d for d in dirnames
            if d not in IGNORED_DIRS
            and not d.startswith(".")
            and not (ignore_pm and _is_pm_dir(dp / d))
        ]
        for fname in filenames:
            fp = dp / fname
            if fp.suffix.lower() not in formatters:
                continue
            if _is_binary(fp):
                continue
            try:
                if fp.stat().st_size > MAX_FILE_SIZE:
                    log.warning("Skipping oversized file: %s", fp)
                    continue
            except OSError:
                continue
            found.append(fp)
    return sorted(found)


def _is_pm_dir(path: Path) -> bool:
    return path.name == "pm" and (path / "__init__.py").exists()


# ------------------------------------------------------------------
# I/O helpers
# ------------------------------------------------------------------

def _read(path: Path) -> Optional[tuple[str, str]]:
    for enc in ENCODING_FALLBACKS:
        try:
            return path.read_text(encoding=enc), enc
        except (UnicodeDecodeError, LookupError):
            continue
    return None


def _atomic_write(path: Path, content: str, encoding: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(content, encoding=encoding)
        os.replace(tmp, path)
    except OSError:
        if tmp.exists():
            tmp.unlink(missing_ok=True)
        raise


# ------------------------------------------------------------------
# Main entry point
# ------------------------------------------------------------------

def run_formatter(
    root: Path,
    cache_path: Path,
    max_blank_lines: int = 2,
    ignore_pm: bool = True,
) -> dict:
    """
    Run all formatters under *root*.

    Returns:
        {"processed": int, "unchanged": int, "errors": int, "files": list[str]}
    """
    formatters = _build_formatters(max_blank_lines)
    cache = _load_cache(cache_path)
    files = _discover(root, formatters, ignore_pm=ignore_pm)

    processed = 0
    unchanged = 0
    errors = 0
    changed_files: list[str] = []

    for fp in files:
        key = str(fp)
        try:
            current_hash = _file_hash(fp)
        except OSError:
            errors += 1
            continue

        if cache.get(key) == current_hash:
            unchanged += 1
            continue

        raw = _read(fp)
        if raw is None:
            errors += 1
            continue
        source, encoding = raw

        formatter = formatters[fp.suffix.lower()]
        try:
            cleaned = formatter.process(source)
        except Exception as exc:
            log.error("Formatter error on %s: %s", fp, exc)
            errors += 1
            continue

        if cleaned == source:
            cache[key] = current_hash
            unchanged += 1
            continue

        # Validate Python
        if fp.suffix.lower() == ".py":
            try:
                ast.parse(cleaned)
            except SyntaxError as exc:
                log.error("AST validation failed %s: %s", fp, exc)
                errors += 1
                continue

        try:
            _atomic_write(fp, cleaned, encoding)
            new_hash = _file_hash(fp)
            cache[key] = new_hash
            processed += 1
            changed_files.append(str(fp))
            log.info("Formatted: %s", fp.name)
        except OSError as exc:
            log.error("Write failed %s: %s", fp, exc)
            errors += 1

    _save_cache(cache, cache_path)
    return {
        "processed": processed,
        "unchanged": unchanged,
        "errors": errors,
        "files": changed_files,
    }
