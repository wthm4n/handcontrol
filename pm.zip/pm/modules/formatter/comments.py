"""Python comment-stripping formatter."""

from __future__ import annotations

import io
import tokenize


class PythonCommentRemover:
    """Strips inline and standalone comments from Python source."""

    extensions = [".py"]

    def __init__(self, max_blank_lines: int = 2) -> None:
        self._max_blank = max_blank_lines

    def process(self, source: str) -> str:
        if not source:
            return source
        lines = self._strip_comments(source)
        return self._collapse_blanks(lines)

    def _strip_comments(self, source: str) -> list[str]:
        src_bytes = source.encode("utf-8")
        readline = io.BytesIO(src_bytes).readline
        original = source.splitlines(keepends=True)
        padded = [""] + original   # 1-indexed

        spans: dict[int, list[tuple[int, int]]] = {}
        try:
            for tok in tokenize.tokenize(readline):
                if tok.type == tokenize.COMMENT:
                    row, cs = tok.start
                    _, ce = tok.end
                    spans.setdefault(row, []).append((cs, ce))
        except tokenize.TokenError:
            return original

        result: list[str] = []
        for lineno, line in enumerate(padded):
            if lineno == 0:
                continue
            if lineno not in spans:
                result.append(line)
                continue
            chars = list(line)
            for cs, ce in sorted(spans[lineno], reverse=True):
                del chars[cs:ce]
            cleaned = "".join(chars).rstrip()
            ending = "\r\n" if line.endswith("\r\n") else "\r" if line.endswith("\r") else "\n"
            result.append((cleaned + ending) if cleaned else ending)
        return result

    def _collapse_blanks(self, lines: list[str]) -> str:
        out: list[str] = []
        blanks = 0
        for line in lines:
            if line.strip() == "":
                blanks += 1
                if blanks <= self._max_blank:
                    out.append(line)
            else:
                blanks = 0
                out.append(line)
        # Strip leading blank lines
        while out and out[0].strip() == "":
            out.pop(0)
        return "".join(out)
