"""Formatter module — comment stripping today, pluggable per-language formatters in future."""
