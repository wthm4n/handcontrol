"""git push."""

from __future__ import annotations

from pathlib import Path

from ._exec import run_git


def push(root: Path, remote: str = "origin", branch: str | None = None) -> str:
    args = ["push", remote]
    if branch:
        args.append(branch)
    return run_git(args, cwd=root)
