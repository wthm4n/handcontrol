"""Git module — status, add, commit, push, pull, diff. No AI logic lives here."""
