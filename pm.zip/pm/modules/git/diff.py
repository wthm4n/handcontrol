"""git diff — collects changed files + diff text for the AI analyzer.

This module only produces raw git data. It has no knowledge of Ollama,
prompts, or analysis — that lives in pm/ai/analyzer.py and is invoked
from the tasks layer, never from here.
"""

from __future__ import annotations

from pathlib import Path

from ._exec import run_git
from .status import porcelain_files


def diff(root: Path, staged: bool = False) -> str:
    args = ["diff", "--staged"] if staged else ["diff"]
    return run_git(args, cwd=root)


def collect(root: Path) -> tuple[list[str], str]:
    """Collect (changed_files, diff_text) for AI analysis.

    Includes both staged and unstaged changes so the analyzer always
    sees the full working-tree delta, regardless of what's been
    `git add`ed yet.
    """
    files = porcelain_files(root)
    unstaged = diff(root, staged=False)
    staged = diff(root, staged=True)
    combined = "\n".join(part for part in (staged, unstaged) if part)
    return files, combined
