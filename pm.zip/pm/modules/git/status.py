"""git status / add."""

from __future__ import annotations

from pathlib import Path

from ._exec import run_git


def status(root: Path, short: bool = True) -> str:
    """Human-readable `git status` (porcelain by default)."""
    args = ["status", "--short"] if short else ["status"]
    return run_git(args, cwd=root)


def porcelain_files(root: Path) -> list[str]:
    """Return changed file paths from `git status --porcelain`.

    Note: for simple add/modify/delete entries this strips the 2-char
    status code cleanly. Rename entries ("R  old -> new") are returned
    as-is; callers that need the new path only should split on " -> ".
    """
    out = run_git(["status", "--porcelain"], cwd=root)
    files: list[str] = []
    for line in out.splitlines():
        if not line.strip():
            continue
        files.append(line[3:].strip())
    return files


def add(root: Path, paths: list[str] | None = None) -> None:
    """Stage *paths*, or everything if paths is None/empty."""
    targets = paths if paths else ["-A"]
    run_git(["add", *targets], cwd=root)


def current_branch(root: Path) -> str:
    return run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd=root)


def has_uncommitted_changes(root: Path) -> bool:
    return bool(run_git(["status", "--porcelain"], cwd=root))
