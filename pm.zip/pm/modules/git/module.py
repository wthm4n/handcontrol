"""Git module — status, add, commit, push, pull, diff.

No AI logic lives here, by design (see project spec). Commit-message
generation via Ollama is orchestrated one layer up, in pm/tasks/, which
passes a plain string into GitModule.commit(). This module only ever
talks to git.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ...eventbus import Events
from ...module import Module
from . import commit as _commit
from . import diff as _diff
from . import pull as _pull
from . import push as _push
from . import status as _status

if TYPE_CHECKING:
    from ...manager import ProjectManager

log = logging.getLogger("pm.git")


class GitModule(Module):
    """
    Wraps git CLI operations for the project.

    Emits:
        Events.GIT_STAGED     (paths=list[str] | None)
        Events.GIT_COMMITTED  (hash=str | None, message=str)
        Events.GIT_PUSHED
        Events.GIT_PULLED

    Subscribes to Events.FORMATTER_COMPLETED for auto_commit/auto_push
    when enabled in config — the formatter never calls git directly,
    it only emits an event and git decides what to do with it.

    Note: if [git].auto_commit is enabled, a plain (non-AI) commit may
    already happen here as soon as the formatter finishes. Running the
    "sync" task afterwards will then find nothing left to commit. If you
    want AI-generated commit messages via the sync task, set
    auto_commit = false and drive commits through `pm.tasks.run("sync")`
    or `python -m pm sync` instead.
    """

    name = "git"

    def setup(self, pm: "ProjectManager") -> None:
        self._pm = pm
        self._cfg = pm.config.git
        self._root = pm.root

        if self._cfg.enabled and self._cfg.auto_commit:
            pm.events.subscribe(Events.FORMATTER_COMPLETED, self._on_formatter_completed)
            log.debug("Auto-commit enabled — subscribed to FORMATTER_COMPLETED")

    # ------------------------------------------------------------------
    # Public API (pm.git.*)
    # ------------------------------------------------------------------

    def status(self) -> str:
        return _status.status(self._root)

    def add(self, paths: list[str] | None = None) -> None:
        _status.add(self._root, paths)
        self._pm.events.emit(Events.GIT_STAGED, paths=paths)

    def commit(self, message: str | None = None) -> str | None:
        """Stage and commit. *message* falls back to config.git.commit_message."""
        message = message or self._cfg.commit_message
        result = _commit.commit(self._root, message)
        self._pm.events.emit(Events.GIT_COMMITTED, hash=result, message=message)
        if result:
            log.info("[git] Commit created: %s", result[:8])
        else:
            log.info("[git] Nothing to commit")
        return result

    def push(self) -> str:
        result = _push.push(self._root, remote=self._cfg.remote, branch=self._cfg.branch)
        self._pm.events.emit(Events.GIT_PUSHED)
        log.info("[git] Pushed to %s/%s", self._cfg.remote, self._cfg.branch)
        return result

    def pull(self) -> str:
        result = _pull.pull(self._root, remote=self._cfg.remote, branch=self._cfg.branch)
        self._pm.events.emit(Events.GIT_PULLED)
        log.info("[git] Pulled from %s/%s", self._cfg.remote, self._cfg.branch)
        return result

    def diff(self, staged: bool = False) -> str:
        return _diff.diff(self._root, staged=staged)

    def log(self, count: int = 10) -> list[str]:
        return _commit.log(self._root, count=count)

    def collect_diff(self) -> tuple[list[str], str]:
        """(changed_files, diff_text) — consumed by pm/ai/analyzer.py via tasks/analyze.py."""
        return _diff.collect(self._root)

    def current_branch(self) -> str:
        return _status.current_branch(self._root)

    def has_uncommitted_changes(self) -> bool:
        return _status.has_uncommitted_changes(self._root)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _on_formatter_completed(self, processed: int = 0, **_) -> None:
        if processed <= 0:
            return
        log.debug("[formatter] → git auto-commit triggered (%d files)", processed)
        self.commit()
        if self._cfg.auto_push:
            self.push()
