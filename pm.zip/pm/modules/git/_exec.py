"""Low-level git command execution shared by all git/* helpers.

Kept separate from module.py so every other file in this package
(status, commit, push, pull, diff) has exactly one place that shells
out to the `git` binary.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from ...exceptions import GitError


def run_git(args: list[str], cwd: Path, timeout: int = 30) -> str:
    """Run `git <args>` in *cwd* and return stdout, stripped.

    Raises GitError if git is missing, times out, or exits non-zero.
    """
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise GitError("git executable not found on PATH") from exc
    except subprocess.TimeoutExpired as exc:
        raise GitError(f"git {' '.join(args)} timed out after {timeout}s") from exc

    if result.returncode != 0:
        raise GitError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()
