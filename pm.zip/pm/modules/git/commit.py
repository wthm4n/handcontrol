"""git commit.

Pure git — takes a plain message string. Commit-message generation
(AI or otherwise) is the caller's responsibility, never this module's.
"""

from __future__ import annotations

from pathlib import Path

from ._exec import run_git
from .status import add, has_uncommitted_changes


def commit(root: Path, message: str, stage_all: bool = True) -> str | None:
    """Stage and commit. Returns the new commit hash, or None if there
    was nothing to commit."""
    if stage_all:
        add(root)
    if not has_uncommitted_changes(root):
        return None
    run_git(["commit", "-m", message], cwd=root)
    return run_git(["rev-parse", "HEAD"], cwd=root)


def log(root: Path, count: int = 10) -> list[str]:
    """Return the last *count* commit subjects, newest first."""
    out = run_git(["log", f"-{count}", "--pretty=format:%h %s"], cwd=root)
    return out.splitlines() if out else []
