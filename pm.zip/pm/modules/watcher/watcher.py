"""
File system watcher using polling (no external dependencies).

Uses a background thread that polls file mtimes. When a change is
detected it emits events on the PM event bus.

For production use, swap the polling backend with watchdog:
    pip install watchdog
and override _make_observer() in FileWatcher.
"""

from __future__ import annotations

import fnmatch
import logging
import os
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from ...eventbus import EventBus

log = logging.getLogger("pm.watcher")

# Directories always ignored by the watcher.
_IGNORED_DIRS = frozenset({
    ".git", "__pycache__", ".venv", "venv", "build", "dist",
    ".mypy_cache", ".pytest_cache", ".tox", "node_modules", ".idea", ".vscode",
})

ChangedCallback = Callable[[Path, str], None]  # (path, event_type)


class FileWatcher:
    """
    Polling-based file watcher.

    Calls *callback(path, event_type)* when a file is created, modified,
    or deleted. *event_type* is one of: "created", "modified", "deleted".

    Debouncing is applied: rapid successive changes to the same file
    within *debounce_ms* milliseconds are collapsed into one event.
    """

    POLL_INTERVAL = 1.0  # seconds

    def __init__(
        self,
        root: Path,
        callback: ChangedCallback,
        recursive: bool = True,
        debounce_ms: int = 300,
        ignore_patterns: tuple[str, ...] = (),
        ignore_pm: bool = True,
    ) -> None:
        self._root = root
        self._callback = callback
        self._recursive = recursive
        self._debounce = debounce_ms / 1000.0
        self._ignore_patterns = ignore_patterns
        self._ignore_pm = ignore_pm

        self._snapshot: dict[Path, float] = {}
        self._pending: dict[Path, float] = {}  # path → earliest pending time
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._snapshot = self._scan()
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop, name="pm-watcher", daemon=True
        )
        self._thread.start()
        log.info("Watcher started (root=%s recursive=%s)", self._root, self._recursive)

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3)
        log.info("Watcher stopped")

    # ------------------------------------------------------------------
    # Internal loop
    # ------------------------------------------------------------------

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            time.sleep(self.POLL_INTERVAL)
            try:
                self._tick()
            except Exception:
                log.exception("Watcher error")

    def _tick(self) -> None:
        now = time.monotonic()
        current = self._scan()

        # Detect new / modified
        for path, mtime in current.items():
            old_mtime = self._snapshot.get(path)
            if old_mtime is None:
                self._queue(path, "created", now)
            elif mtime != old_mtime:
                self._queue(path, "modified", now)

        # Detect deleted
        for path in set(self._snapshot) - set(current):
            self._queue(path, "deleted", now)

        self._snapshot = current

        # Fire debounced events
        ready = [p for p, t in list(self._pending.items()) if now - t >= self._debounce]
        for path in ready:
            event_type = "modified"  # best guess after debounce
            del self._pending[path]
            try:
                self._callback(path, event_type)
            except Exception:
                log.exception("Watcher callback error for %s", path)

    def _queue(self, path: Path, event_type: str, now: float) -> None:
        if path not in self._pending:
            self._pending[path] = now
            log.debug("[watcher] queued %s %s", event_type, path)

    # ------------------------------------------------------------------
    # Scanning
    # ------------------------------------------------------------------

    def _scan(self) -> dict[Path, float]:
        result: dict[Path, float] = {}
        try:
            if self._recursive:
                for dirpath, dirnames, filenames in os.walk(self._root):
                    dp = Path(dirpath)
                    dirnames[:] = [
                        d for d in dirnames
                        if d not in _IGNORED_DIRS
                        and not d.startswith(".")
                        and not self._is_pm_dir(dp / d)
                    ]
                    for fname in filenames:
                        fp = dp / fname
                        if not self._should_ignore(fp):
                            try:
                                result[fp] = fp.stat().st_mtime
                            except OSError:
                                pass
            else:
                for item in self._root.iterdir():
                    if item.is_file() and not self._should_ignore(item):
                        try:
                            result[item] = item.stat().st_mtime
                        except OSError:
                            pass
        except OSError:
            pass
        return result

    def _is_pm_dir(self, path: Path) -> bool:
        if not self._ignore_pm:
            return False
        return path.name == "pm" and (path / "__init__.py").exists()

    def _should_ignore(self, path: Path) -> bool:
        name = path.name
        for pat in self._ignore_patterns:
            if fnmatch.fnmatch(name, pat):
                return True
        return False
