"""Watcher module — detects file changes and emits events."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from ...eventbus import Events
from ...module import Module
from .watcher import FileWatcher

if TYPE_CHECKING:
    from ...manager import ProjectManager

log = logging.getLogger("pm.watcher")


class WatcherModule(Module):
    """
    Watches the project directory tree for file changes.

    On each change emits one of:
        Events.FILE_CHANGED  (path=Path, event_type=str)
        Events.FILE_CREATED  (path=Path)
        Events.FILE_DELETED  (path=Path)

    Respects project.ignore_pm to exclude the pm/ directory itself.
    """

    name = "watcher"

    def setup(self, pm: "ProjectManager") -> None:
        self._pm = pm
        self._cfg = pm.config.watcher
        self._watcher: FileWatcher | None = None

        if not self._cfg.enabled:
            log.info("Watcher disabled via config")
            return

        self._watcher = FileWatcher(
            root=pm.root,
            callback=self._on_change,
            recursive=self._cfg.recursive,
            debounce_ms=self._cfg.debounce_ms,
            ignore_patterns=self._cfg.ignore_patterns,
            ignore_pm=pm.config.project.ignore_pm,
        )

    def start(self) -> None:
        if self._watcher:
            self._watcher.start()

    def shutdown(self) -> None:
        if self._watcher:
            self._watcher.stop()

    def _on_change(self, path: Path, event_type: str) -> None:
        log.info("File %s: %s", event_type, path)
        self._pm.events.emit(Events.FILE_CHANGED, path=path, event_type=event_type)
        if event_type == "created":
            self._pm.events.emit(Events.FILE_CREATED, path=path)
        elif event_type == "deleted":
            self._pm.events.emit(Events.FILE_DELETED, path=path)
