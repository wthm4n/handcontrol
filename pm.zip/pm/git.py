"""Git integration. Every git invocation in PM goes through `_run()` here —
no other module shells out to the `git` binary directly.
"""

from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


class GitError(Exception):
    pass


@dataclass
class FileChange:
    path: str
    status: str  # "M" modified, "A" added, "D" deleted, "?" untracked


def is_installed() -> bool:
    return shutil.which("git") is not None


def _run(args: list[str], cwd: Path, timeout: int = 30, check: bool = True) -> str:
    try:
        result = subprocess.run(
            ["git", *args], cwd=cwd, capture_output=True, text=True, timeout=timeout
        )
    except FileNotFoundError as exc:
        raise GitError("git executable not found on PATH") from exc
    except subprocess.TimeoutExpired as exc:
        raise GitError(f"git {' '.join(args)} timed out") from exc

    if check and result.returncode != 0:
        raise GitError(result.stderr.strip() or f"git {' '.join(args)} failed")
    # NOTE: only trim trailing newlines here, never the whole string — the
    # porcelain status format has a *significant* leading space on each
    # line (e.g. " M file.py"), which a blanket .strip() would eat.
    return result.stdout.rstrip("\n")


def is_repo(root: Path) -> bool:
    try:
        _run(["rev-parse", "--is-inside-work-tree"], root)
        return True
    except GitError:
        return False


def init(root: Path) -> str:
    return _run(["init"], root)


def current_branch(root: Path) -> str:
    try:
        return _run(["branch", "--show-current"], root).strip() or "(detached)"
    except GitError:
        return "(none)"


def changed_files(root: Path) -> list[FileChange]:
    """Parse `git status --porcelain` into a flat list of changed files."""
    try:
        out = _run(["status", "--porcelain"], root)
    except GitError:
        return []
    changes: list[FileChange] = []
    for line in out.splitlines():
        if not line.strip():
            continue
        code = line[:2].strip()
        path = line[3:].strip().strip('"')
        status = "?" if code in ("??", "?") else code[0] if code[0] != " " else code[1]
        changes.append(FileChange(path=path, status=status or "M"))
    return changes


def diff_for(root: Path, path: str) -> str:
    """Unified diff for one file — staged + unstaged combined."""
    try:
        staged = _run(["diff", "--cached", "--", path], root, check=False)
        unstaged = _run(["diff", "--", path], root, check=False)
    except GitError:
        return ""
    parts = [p for p in (staged, unstaged) if p.strip()]
    diff = "\n".join(parts)
    if diff:
        return diff
    # New/untracked file — show its content as an additive diff.
    try:
        return _run(["diff", "--no-index", "/dev/null", path], root, check=False)
    except GitError:
        return ""


def full_diff(root: Path) -> str:
    try:
        return _run(["diff"], root, check=False)
    except GitError:
        return ""


def commit_file(root: Path, path: str, message: str) -> str:
    """Stage exactly one file and commit it. This is the only commit path
    PM ever uses — every commit is scoped to a single file."""
    _run(["add", "--", path], root)
    return _run(["commit", "-m", message, "--", path], root)


def push(root: Path, remote: str, branch: str) -> str:
    return _run(["push", remote, branch], root)


def pull(root: Path, remote: str, branch: str) -> str:
    return _run(["pull", remote, branch], root)


def log(root: Path, n: int = 10) -> str:
    return _run(["log", f"-{n}", "--oneline", "--decorate"], root, check=False)
