"""
Command-line interface for PM.

    python -m pm                 → interactive mode
    python -m pm status
    python -m pm format
    python -m pm analyze
    python -m pm commit ["message"]
    python -m pm push
    python -m pm pull
    python -m pm sync
"""

from __future__ import annotations

import argparse
import sys

from .exceptions import PMError
from .manager import ProjectManager

COMMANDS = ["status", "format", "analyze", "commit", "push", "pull", "sync"]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pm", description="PM — project automation framework")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("status", help="Show git status")
    sub.add_parser("format", help="Run the formatter over the project")
    sub.add_parser("analyze", help="Run AI diff analysis (requires [ollama].enabled)")
    p_commit = sub.add_parser("commit", help="Stage and commit")
    p_commit.add_argument("message", nargs="?", default=None, help="Commit message")
    sub.add_parser("push", help="Push to the configured remote/branch")
    sub.add_parser("pull", help="Pull from the configured remote/branch")
    sub.add_parser("sync", help="format -> analyze -> commit -> push")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        pm = ProjectManager()
        pm.load()
    except PMError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    try:
        if args.command is None:
            return _interactive(pm)
        return _dispatch(pm, args)
    except PMError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    finally:
        pm.shutdown()


def _dispatch(pm: ProjectManager, args: argparse.Namespace) -> int:
    cmd = args.command
    message = getattr(args, "message", None)

    if cmd == "status":
        print(pm.git.status() or "(clean)")
    elif cmd == "format":
        result = pm.formatter.run()
        print(f"processed={result['processed']} unchanged={result['unchanged']} errors={result['errors']}")
    elif cmd == "analyze":
        result = pm.tasks.run("analyze")
        print(result.get("analysis") or "(ollama disabled)")
    elif cmd == "commit":
        result = pm.git.commit(message)
        print(f"committed: {result}" if result else "nothing to commit")
    elif cmd == "push":
        pm.git.push()
        print("pushed")
    elif cmd == "pull":
        pm.git.pull()
        print("pulled")
    elif cmd == "sync":
        result = pm.tasks.run("sync")
        print(f"sync complete: commit={result['commit']} push={bool(result['push'])}")
    else:
        print(f"unknown command: {cmd}", file=sys.stderr)
        return 1
    return 0


def _interactive(pm: ProjectManager) -> int:
    print(f"PM interactive — project: {pm.config.project.name}")
    print(f"Commands: {', '.join(COMMANDS)}  (or 'quit')")
    while True:
        try:
            raw = input("pm> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not raw:
            continue
        if raw in ("quit", "exit", "q"):
            return 0
        parts = raw.split(maxsplit=1)
        cmd, rest = parts[0], (parts[1] if len(parts) > 1 else None)
        if cmd not in COMMANDS:
            print(f"unknown command: {cmd}")
            continue
        ns = argparse.Namespace(command=cmd, message=rest)
        try:
            _dispatch(pm, ns)
        except PMError as exc:
            print(f"error: {exc}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
