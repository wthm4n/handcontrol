"""The command registry. Every slash command PM understands is registered
in COMMANDS at the bottom of this file, pointing at a small handler
function above it. `dispatch()` is the only entry point the REPL calls.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from rich.panel import Panel
from rich.syntax import Syntax
from rich.tree import Tree

from . import ai, config as config_mod, formatter, git, ui
from .config import DEFAULT_IGNORE
from .models import CommandSpec
from .sync import run_commit_pipeline
from .utils import discover_files, human_path

PY_SUFFIXES = {".py"}


# ---------------------------------------------------------------------------
# Help / status / exit
# ---------------------------------------------------------------------------

def cmd_help(ctx, args: list[str]) -> None:
    if args:
        name = args[0].lstrip("/")
        spec = COMMANDS.get(name)
        if spec is None:
            ui.error(ctx, f"No such command: /{name}")
            return
        ui.render_help_command(ctx, spec)
    else:
        ui.render_help_index(ctx, COMMANDS)


def cmd_status(ctx, args: list[str]) -> None:
    ui.render_dashboard(ctx)


def cmd_activity(ctx, args: list[str]) -> None:
    n = int(args[0]) if args and args[0].isdigit() else 50
    ctx.console.print(ui.activity_panel(ctx, n))


def cmd_exit(ctx, args: list[str]) -> None:
    if ctx.sync and ctx.sync.is_running:
        ctx.sync.stop()
    ctx.running = False
    ui.info(ctx, "Goodbye.")


# ---------------------------------------------------------------------------
# Sync
# ---------------------------------------------------------------------------

def cmd_sync(ctx, args: list[str]) -> None:
    sub = args[0] if args else "status"
    if sub == "start":
        msg = ctx.sync.start()
        (ui.success if ctx.sync.is_running else ui.warn)(ctx, msg)
    elif sub == "stop":
        ui.warn(ctx, ctx.sync.stop())
    elif sub == "status":
        state = "running" if ctx.sync.is_running else "stopped"
        ui.info(ctx, f"Sync is {state} (debounce {ctx.config.sync.debounce_seconds}s, push={ctx.config.sync.push})")
    else:
        ui.error(ctx, "Usage: /sync start|stop|status")


# ---------------------------------------------------------------------------
# Formatter
# ---------------------------------------------------------------------------

def cmd_format(ctx, args: list[str]) -> None:
    cfg = ctx.config
    target = args[0] if args else "."

    if target == "changed":
        files = [cfg.root / c.path for c in git.changed_files(cfg.root) if (cfg.root / c.path).exists()]
    elif target == ".":
        files = discover_files(cfg.root, cfg.ignore, suffixes=PY_SUFFIXES)
    else:
        p = Path(target)
        files = [p if p.is_absolute() else cfg.root / target]

    changed = formatter.format_paths(files, cfg.formatter.max_blank_lines)
    for f in changed:
        ctx.activity.add(f"Formatted {human_path(f, cfg.root)}", "info")

    if changed:
        ui.success(ctx, f"Formatted {len(changed)} file(s).")
    else:
        ui.info(ctx, "Nothing to format.")


# ---------------------------------------------------------------------------
# AI
# ---------------------------------------------------------------------------

def cmd_analyze(ctx, args: list[str]) -> None:
    cfg = ctx.config
    files = [c.path for c in git.changed_files(cfg.root)]
    diff = git.full_diff(cfg.root)
    if not diff.strip():
        ui.info(ctx, "Nothing to analyze — no local changes.")
        return
    with ctx.console.status("[cyan]Analyzing changes..."):
        try:
            result = ai.analyze_diff(ctx.ai, cfg.project.name, files, diff)
        except ai.OllamaError as exc:
            ui.error(ctx, str(exc))
            return
    ctx.console.print(Panel(result, title="Analysis", border_style=ui.BRAND))


def cmd_review(ctx, args: list[str]) -> None:
    cfg = ctx.config
    file = args[0] if args else None
    diff = git.diff_for(cfg.root, file) if file else git.full_diff(cfg.root)
    label = file or "(all changes)"
    if not diff.strip():
        ui.info(ctx, f"Nothing to review for {label}.")
        return
    with ctx.console.status("[cyan]Reviewing..."):
        try:
            result = ai.review_diff(ctx.ai, label, diff)
        except ai.OllamaError as exc:
            ui.error(ctx, str(exc))
            return
    ctx.console.print(Panel(result, title=f"Review: {label}", border_style=ui.BRAND))


def cmd_message(ctx, args: list[str]) -> None:
    cfg = ctx.config
    if not args:
        ui.error(ctx, "Usage: /message <file>")
        return
    file = args[0]
    diff = git.diff_for(cfg.root, file)
    if not diff.strip():
        ui.info(ctx, f"No changes in {file}.")
        return
    with ctx.console.status("[cyan]Generating message..."):
        message, source = ai.generate_commit_message(
            ctx.ai, cfg.ollama.enabled, cfg.git.fallback_commit_message, file, diff
        )
    ui.info(ctx, f"{message} [dim]({source})[/dim]")


def cmd_model(ctx, args: list[str]) -> None:
    cfg = ctx.config
    sub = args[0] if args else "current"
    if sub == "list":
        installed = ctx.ai.list_models()
        ui.render_models(ctx, ai.SUPPORTED_MODELS, cfg.ollama.model, installed)
    elif sub == "current":
        ui.info(ctx, f"Current model: {cfg.ollama.model}")
    else:
        config_mod.set_model(cfg, sub)
        ui.success(ctx, f"Model set to {sub}")


# ---------------------------------------------------------------------------
# Git — shared implementations used by both top-level shortcuts and /git
# ---------------------------------------------------------------------------

def _do_commit(ctx) -> None:
    cfg = ctx.config
    changes = git.changed_files(cfg.root)
    if not changes:
        ui.info(ctx, "Nothing to commit.")
        return
    for c in changes:
        run_commit_pipeline(ctx, cfg.root / c.path, push=False)
    ui.info(ctx, f"Processed {len(changes)} file(s). Run /push to publish.")


def _do_push(ctx) -> None:
    cfg = ctx.config
    try:
        git.push(cfg.root, cfg.git.remote, cfg.git.branch)
        ui.success(ctx, f"Pushed to {cfg.git.remote}/{cfg.git.branch}")
        ctx.activity.add(f"Pushed to {cfg.git.remote}/{cfg.git.branch}", "success")
    except git.GitError as exc:
        ui.error(ctx, str(exc))


def _do_pull(ctx) -> None:
    cfg = ctx.config
    try:
        out = git.pull(cfg.root, cfg.git.remote, cfg.git.branch)
        ui.success(ctx, out or "Already up to date.")
    except git.GitError as exc:
        ui.error(ctx, str(exc))


def _do_diff(ctx, args: list[str]) -> None:
    cfg = ctx.config
    text = git.diff_for(cfg.root, args[0]) if args else git.full_diff(cfg.root)
    if not text.strip():
        ui.info(ctx, "No differences.")
        return
    ctx.console.print(Syntax(text, "diff", theme="ansi_dark", word_wrap=True))


def _do_log(ctx) -> None:
    cfg = ctx.config
    out = git.log(cfg.root)
    ctx.console.print(Panel(out or "[dim]No commits yet.[/dim]", title="Log", border_style="grey50"))


def _do_status(ctx) -> None:
    cfg = ctx.config
    ui.render_git_changes(ctx, git.changed_files(cfg.root))


def cmd_commit(ctx, args: list[str]) -> None:
    _do_commit(ctx)


def cmd_push(ctx, args: list[str]) -> None:
    _do_push(ctx)


def cmd_pull(ctx, args: list[str]) -> None:
    _do_pull(ctx)


def cmd_diff(ctx, args: list[str]) -> None:
    _do_diff(ctx, args)


def cmd_log(ctx, args: list[str]) -> None:
    _do_log(ctx)


def cmd_git(ctx, args: list[str]) -> None:
    if not args:
        ui.error(ctx, "Usage: /git status|diff|log|push|pull")
        return
    sub, rest = args[0], args[1:]
    {
        "status": lambda: _do_status(ctx),
        "diff": lambda: _do_diff(ctx, rest),
        "log": lambda: _do_log(ctx),
        "push": lambda: _do_push(ctx),
        "pull": lambda: _do_pull(ctx),
        "commit": lambda: _do_commit(ctx),
    }.get(sub, lambda: ui.error(ctx, f"Unknown git subcommand: {sub}"))()


# ---------------------------------------------------------------------------
# Project
# ---------------------------------------------------------------------------

def cmd_doctor(ctx, args: list[str]) -> None:
    cfg = ctx.config
    checks = [
        ("Git Installed", git.is_installed(), shutil.which("git") or "not found"),
        ("Git Repo", git.is_repo(cfg.root), str(cfg.root)),
        ("Ollama Running", ctx.ai.is_available(), cfg.ollama.host),
        ("Config Loaded", cfg.path is not None, str(cfg.path) if cfg.path else "using defaults — run /config init"),
        ("Sync Running", bool(ctx.sync and ctx.sync.is_running), "active" if ctx.sync and ctx.sync.is_running else "stopped"),
    ]
    ui.render_doctor(ctx, checks)


def cmd_config(ctx, args: list[str]) -> None:
    cfg = ctx.config
    if args and args[0] == "init":
        path = config_mod.init_config(cfg.root, cfg.project.name)
        cfg.path = path
        ui.success(ctx, f"Wrote {path}")
        return
    if cfg.path and cfg.path.exists():
        ctx.console.print(Syntax(cfg.path.read_text(encoding="utf-8"), "toml"))
    else:
        ui.warn(ctx, "No .src file found. Run /config init to create one.")


def cmd_tree(ctx, args: list[str]) -> None:
    cfg = ctx.config
    root_node = Tree(f"[bold]{cfg.root.name}[/bold]")

    def add(node: Tree, path: Path, depth: int) -> None:
        if depth > 3:
            return
        try:
            entries = sorted(path.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
        except OSError:
            return
        for entry in entries:
            if entry.name in DEFAULT_IGNORE or entry.name in cfg.ignore or entry.name.startswith("."):
                continue
            if entry.is_dir():
                branch = node.add(f"[bold cyan]{entry.name}/[/bold cyan]")
                add(branch, entry, depth + 1)
            else:
                node.add(entry.name)

    add(root_node, cfg.root, 0)
    ctx.console.print(root_node)


def cmd_files(ctx, args: list[str]) -> None:
    cfg = ctx.config
    files = discover_files(cfg.root, cfg.ignore)
    ui.render_files(ctx, [human_path(f, cfg.root) for f in files])


def cmd_root(ctx, args: list[str]) -> None:
    ui.info(ctx, str(ctx.config.root))


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

COMMANDS: dict[str, CommandSpec] = {
    "help": CommandSpec(
        "help", cmd_help, "Show available commands, or details for one.",
        usage=["/help", "/help <command>"], examples=["/help", "/help format"],
    ),
    "status": CommandSpec(
        "status", cmd_status, "Show project status and recent activity.",
        usage=["/status"], examples=["/status"],
    ),
    "activity": CommandSpec(
        "activity", cmd_activity, "Show the activity feed.",
        usage=["/activity", "/activity <count>"], examples=["/activity", "/activity 20"],
    ),
    "sync": CommandSpec(
        "sync", cmd_sync, "Start, stop, or check file-watch sync.",
        usage=["/sync start", "/sync stop", "/sync status"],
        examples=["/sync start", "/sync stop"],
    ),
    "format": CommandSpec(
        "format", cmd_format, "Format files (strip comments, collapse blank lines).",
        usage=["/format .", "/format <file>", "/format changed"],
        examples=["/format .", "/format src/main.py", "/format changed"],
    ),
    "analyze": CommandSpec(
        "analyze", cmd_analyze, "AI summary of all local changes.",
        usage=["/analyze"], examples=["/analyze"],
    ),
    "review": CommandSpec(
        "review", cmd_review, "AI code review of a file's changes (or everything).",
        usage=["/review", "/review <file>"], examples=["/review src/main.py"],
    ),
    "message": CommandSpec(
        "message", cmd_message, "Preview an AI commit message for a file (no commit).",
        usage=["/message <file>"], examples=["/message src/main.py"],
    ),
    "model": CommandSpec(
        "model", cmd_model, "List, show, or switch the active Ollama model.",
        usage=["/model list", "/model current", "/model <name>"],
        examples=["/model list", "/model qwen2.5-coder:7b-instruct-q4_K_M"],
    ),
    "git": CommandSpec(
        "git", cmd_git, "Run a git subcommand.",
        usage=["/git status", "/git diff", "/git log", "/git push", "/git pull"],
        examples=["/git status", "/git diff src/main.py"],
    ),
    "commit": CommandSpec(
        "commit", cmd_commit, "Commit every changed file individually with an AI message.",
        usage=["/commit"], examples=["/commit"],
    ),
    "push": CommandSpec("push", cmd_push, "Push commits to the remote.", usage=["/push"], examples=["/push"]),
    "pull": CommandSpec("pull", cmd_pull, "Pull from the remote.", usage=["/pull"], examples=["/pull"]),
    "diff": CommandSpec(
        "diff", cmd_diff, "Show a diff for one file, or everything.",
        usage=["/diff", "/diff <file>"], examples=["/diff", "/diff src/main.py"],
    ),
    "log": CommandSpec("log", cmd_log, "Show recent commits.", usage=["/log"], examples=["/log"]),
    "doctor": CommandSpec(
        "doctor", cmd_doctor, "Run health checks on git, Ollama, config, and sync.",
        usage=["/doctor"], examples=["/doctor"],
    ),
    "config": CommandSpec(
        "config", cmd_config, "Show the current .src config, or create one.",
        usage=["/config", "/config init"], examples=["/config init"],
    ),
    "tree": CommandSpec("tree", cmd_tree, "Show the project file tree.", usage=["/tree"], examples=["/tree"]),
    "files": CommandSpec("files", cmd_files, "List tracked/formattable files.", usage=["/files"], examples=["/files"]),
    "root": CommandSpec("root", cmd_root, "Show the detected project root.", usage=["/root"], examples=["/root"]),
    "exit": CommandSpec("exit", cmd_exit, "Exit PM (stops sync if running).", usage=["/exit"], examples=["/exit"]),
}
COMMANDS["quit"] = COMMANDS["exit"]


def dispatch(ctx, raw: str) -> None:
    raw = raw.strip()
    if not raw:
        return
    if not raw.startswith("/"):
        ui.warn(ctx, "PM only understands slash commands. Try /help.")
        return

    parts = raw[1:].split()
    if not parts:
        return
    name, args = parts[0].lower(), parts[1:]

    spec = COMMANDS.get(name)
    if spec is None:
        ui.error(ctx, f"Unknown command: /{name}. Try /help.")
        return

    try:
        spec.handler(ctx, args)
    except Exception as exc:  # a broken command should never crash the REPL
        ui.error(ctx, f"/{name} failed: {exc}")
