"""Project root discovery + .src config loading/saving.

The config file is named `.src` and lives at the project root. It's plain
TOML (see DEFAULT_TOML below). We use the stdlib `tomllib` to read it and a
tiny hand-rolled writer for `/config init` — no extra dependency needed for
a config this flat.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

from .models import (
    Config,
    FormatterConfig,
    GitConfig,
    OllamaConfig,
    ProjectConfig,
    SyncConfig,
)

CONFIG_FILENAME = ".src"


DEFAULT_IGNORE = ["__pycache__", ".venv", "venv", "dist", "build", ".git", "pm"]

DEFAULT_TOML = """\
version = 3

[project]
name = "{name}"

[ollama]
enabled = true
model = "qwen2.5-coder:7b-instruct-q4_K_M"
host = "http://localhost:11434"
timeout = 60

[sync]
enabled = false
debounce_seconds = 30
push = true

[git]
branch = "main"
remote = "origin"
fallback_commit_message = "chore: update {{file}}"

[formatter]
enabled = true
max_blank_lines = 2

[ignore]
patterns = []
"""


def find_root(start: Path | None = None) -> Path | None:
    """Walk upward from *start* looking for a `.src` file. None if not found."""
    current = (start or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        if (directory / CONFIG_FILENAME).exists():
            return directory
    return None


def load_config(root: Path) -> Config:
    """Load `.src` from *root*. Returns sane defaults if the file is missing
    or partially filled in — PM should still run without a perfect config."""
    cfg_path = root / CONFIG_FILENAME
    data: dict = {}
    if cfg_path.exists():
        try:
            data = tomllib.loads(cfg_path.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, OSError):
            data = {}

    project = data.get("project", {})
    ollama = data.get("ollama", {})
    sync = data.get("sync", {})
    git = data.get("git", {})
    formatter = data.get("formatter", {})
    ignore = data.get("ignore", {})

    return Config(
        version=data.get("version", 3),
        project=ProjectConfig(name=project.get("name", root.name)),
        ollama=OllamaConfig(
            enabled=ollama.get("enabled", True),
            model=ollama.get("model", OllamaConfig.model),
            host=ollama.get("host", OllamaConfig.host),
            timeout=ollama.get("timeout", OllamaConfig.timeout),
        ),
        sync=SyncConfig(
            enabled=sync.get("enabled", False),
            debounce_seconds=sync.get("debounce_seconds", 30),
            push=sync.get("push", True),
        ),
        git=GitConfig(
            branch=git.get("branch", "main"),
            remote=git.get("remote", "origin"),
            fallback_commit_message=git.get(
                "fallback_commit_message", "chore: update {file}"
            ),
        ),
        formatter=FormatterConfig(
            enabled=formatter.get("enabled", True),
            max_blank_lines=formatter.get("max_blank_lines", 2),
        ),
        ignore=list(ignore.get("patterns", [])),
        root=root,
        path=cfg_path if cfg_path.exists() else None,
    )


def init_config(root: Path, name: str | None = None) -> Path:
    """Write a default `.src` file at *root*. Returns the file path."""
    cfg_path = root / CONFIG_FILENAME
    content = DEFAULT_TOML.format(name=name or root.name)
    cfg_path.write_text(content, encoding="utf-8")
    return cfg_path


def set_model(cfg: Config, model: str) -> None:
    """Update the ollama model in memory and persist it to disk if a .src
    file exists. Keeps the rest of the file untouched by doing a targeted
    text replace rather than a full re-serialize."""
    cfg.ollama.model = model
    if cfg.path is None or not cfg.path.exists():
        return
    text = cfg.path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    in_ollama = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("["):
            in_ollama = stripped == "[ollama]"
            continue
        if in_ollama and stripped.startswith("model"):
            lines[i] = f'model = "{model}"\n'
            break
    cfg.path.write_text("".join(lines), encoding="utf-8")


def is_ignored(path: Path, root: Path, extra_patterns: list[str]) -> bool:
    """True if any path component matches a default or user ignore pattern."""
    try:
        rel_parts = path.relative_to(root).parts
    except ValueError:
        rel_parts = path.parts
    patterns = set(DEFAULT_IGNORE) | set(extra_patterns)
    for part in rel_parts:
        if part in patterns or part.startswith("."):
            return True
    return False
